
function openPopup(playlistTitle) {
    document.getElementById("popupTitle").innerText = playlistTitle;
    document.getElementById("popup").style.display = "flex";
}

function closePopup() {
    document.getElementById("popup").style.display = "none";
}
